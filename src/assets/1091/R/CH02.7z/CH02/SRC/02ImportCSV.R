#Set working directory
setwd(file.path("D:","R","CH02","SRC"))
#Set file path
file <- file.path("data","01Sample.csv")
my.data <- read.csv(file)
str(my.data)
my.data