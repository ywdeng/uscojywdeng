setwd("D:/R/CH02/SRC")  # 需視情況調整

# 讀檔案輸入一疊撲克牌
deck <- read.csv("dada/deck.csv", stringsAsFactors = TRUE)

# 檢視結構與內容
str(deck)
head(deck, 20)  # 列出前 20 筆資料

h <- deck[sample(52, 5),]   # 隨機抽取 5 張牌
h   # 觀察內容

# 按照點數大小排序
h <- h[order(h$value),]
h

# 不印 row name
print.data.frame(h, row.names = FALSE)

# 發牌、排序、列印 一次搞定：
h <- deck[sample(52, 5),]; print.data.frame(h[order(h$value),], row.names = FALSE)