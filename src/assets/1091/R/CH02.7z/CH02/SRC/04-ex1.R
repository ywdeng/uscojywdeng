# weight <- read.csv("data/6-15學生平均體重.csv", fileEncoding="UTF-8-BOM")

# 政府開放資料:學生體重平均值(6歲-15歲)
# https://scidm.nchc.org.tw/dataset/54352aee-ef21-4b75-84c4-727525995bf2/resource/d5e69f75-e5a2-4789-b687-10bd6e4f109c/nchcproxy/revnew1.csv

url <- "https://scidm.nchc.org.tw/dataset/54352aee-ef21-4b75-84c4-727525995bf2/resource/d5e69f75-e5a2-4789-b687-10bd6e4f109c/nchcproxy/revnew1.csv"
w <- read.table(url, sep=",", quote = "\"", header=TRUE, encoding="UTF-8")

# 觀察結構與內容
str(w)
head(w, 20)

# 觀察 15 歲學生的平均體重
w[w$年齡==15,]

# 觀察 6 歲學生的平均體重
w6 <- w[w$年齡==6,]; w6
x6 <- as.vector(w6$學年度)
y6 <- as.vector(w6$總計.公斤)
plot(x6, y6, xlab="學年度", ylab="6歲平均體重")

