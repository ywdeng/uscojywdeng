library(RODBC)
db <- odbcConnect(dsn="IRIS")
df <- sqlQuery(db,"SELECT * FROM IRIS")
df
str(df)
sqlQuery(db,"SELECT DISTINCT Species FROM IRIS")
sqlQuery(db,"SELECT COUNT(*) FROM IRIS")
sqlQuery(db,"SELECT * FROM IRIS WHERE Species='versicolor'")
sqlQuery(db,"SELECT Species, COUNT(*) AS [Count], AVG(SepalLength) AS [Average Sepal Length] FROM IRIS GROUP BY Species")