url <- "http://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
setwd(file.path("D:","R","CH02","SRC"))     # 需視情況調整
local <- file.path("data","03DownloadedFile.data")  # 本地檔案
download.file(url,local)    # 下載資料、存入本地檔案
my.data <- read.table(local,sep=",")    # 讀取檔案
str(my.data)    # 查看結構
tail(my.data)   # 列印最末幾筆資料

# 更改欄位名稱：花萼長度、花萼寬度、花瓣長度、花瓣寬度、品種
colnames(my.data) <- c("Sepal Length","Sepal Width",
    "Petal Length","Petal Width","Species")
head(my.data)   # 列印最初幾筆資料