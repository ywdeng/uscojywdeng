#Set working directory
setwd(file.path("D:","R","CH02","SRC"))
#Set file path
file <- file.path("data","02Sample.txt")
my.data <- read.table(file,
    header=TRUE, skip=1,
    colClasses=c("character","factor",
        "numeric","integer","integer"))
str(my.data)