my.data <- scan(file="", what=list(name="",marks=integer(0),gender=""))
"Andy" 70 "Male"
"John" 75 "Male"
"Mary" 80 "Female"
"Susan" 85 "Female"

my.data
str(my.data)
