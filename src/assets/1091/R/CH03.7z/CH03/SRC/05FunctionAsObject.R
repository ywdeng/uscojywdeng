GetTotalMarks <- function(quiz.marks, viva.marks) { 
  total.marks <- quiz.marks + viva.marks  
  total.marks
}
quiz <- c(70L, 75L, 80L, 85L)
oral <- c(7L, 5L, 8L, 6L)
MyTotal <- GetTotalMarks
MyTotal

MyTotal(quiz.marks = quiz, viva.marks = oral) 

do.call(GetTotalMarks,list(quiz, oral))