# A scalar function converts percentage mark to grade
mark2grade.v2 <- function(mark) {
  if (mark > 100 || mark < 0) {
    grade <- 'X'
  } else if (mark >= 80) {
    grade <- 'A'
  } else if (mark >= 70) {
    grade <- 'B'
  } else if (mark >= 60) {
    grade <- 'C'
  } else if (mark >= 50) {
    grade <- 'D'
  } else {
    grade <- 'E'
  }
  grade
}

mark2grade.v2(90)
mark2grade.v2(80)
mark2grade.v2(70)
mark2grade.v2(60)
mark2grade.v2(50)
mark2grade.v2(0)
mark2grade.v2(100)
mark2grade.v2(123)
mark2grade.v2(-123)