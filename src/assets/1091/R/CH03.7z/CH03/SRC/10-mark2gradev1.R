# A scalar function converts percentage mark to grade
mark2grade.v1 <- function(mark) {
  if (mark >= 80 && mark <= 100) {
    grade <- 'A'
  } else if (mark >= 70 && mark <= 79) {
    grade <- 'B'
  } else if (mark >= 60 && mark <= 69) {
    grade <- 'C'
  } else if (mark >= 50 && mark <= 59) {
    grade <- 'D'
  } else if (mark >= 0 && mark < 50) {
    grade <- 'E'
  } else {
    grade <- 'X'
  }
  grade
}

mark2grade.v1(90)
mark2grade.v1(80)
mark2grade.v1(70)
mark2grade.v1(60)
mark2grade.v1(50)
mark2grade.v1(0)
mark2grade.v1(100)
mark2grade.v1(123)
mark2grade.v1(-123)