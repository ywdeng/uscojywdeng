setwd("D:/R/CH03/SRC/data")

files <- list.files(path = ".", 
            pattern = "^A[[:digit:]]{3}.*CSV$")
                         
grd <- rep(0, length(files))
cls <- rep("Z", length(files))
for (i in 1:length(files)) {
    n <- substr(files[i], 2, 3) # 取出年份
    t <- substr(files[i], 4, 4) # 取出班別
    grd[i] <- 20 - as.integer(n) + 1
    cls[i] <- LETTERS[as.integer(t)]
}
dept <- cbind(grd, cls, files)
colnames(dept) <- c("年級", "班級", "成績檔案")
dept

# 計算每一位同學的總成績與排名
summarize <- function(x) {
    h <- nrow(x) #高度,資料筆數
    w <- ncol(x) #寬度,欄位數量    
    # data.frame 增加一欄 總成績
    total <- c(1:h)
    cn <- colnames(x)    # 原有欄位名稱
    x <- cbind(x, total) # 增加一欄
    colnames(x) <- c(cn, "總成績")    
    for (r in 1:h) {
        x[r,w+1] <- sum(x[r,3:w])
    }    
    # data.frame 增加一欄 排名
    rnk <- rank(100 - x[,w+1], ties.method= "min")
    cn <- colnames(x)    # 原有欄位名稱
    x <- cbind(x, rnk) # 增加一欄
    colnames(x) <- c(cn, "名次")    
    return(x)
}

for (i in 1:nrow(dept)) {
    print(paste(dept[i, 1], "年", dept[i, 2], "班書卷獎："))
    score <- read.csv(dept[i, 3], fileEncoding = "utf-8")
    final <- summarize(score)
    sorted <- final[order(final[,8], decreasing = TRUE),]
    top3 <- sorted[sorted[,9] <= 3,]
    rownames(top3) <- NULL
    print(top3)
}
