# A scalar function converts percentage mark to grade
mark2grade.v4 <- function(mark) {
  if (mark < 0 || mark > 100) {
    grade <- 'X'
  } else {
    grade <- switch((mark %/% 10) + 1, 
         'E','E','E','E','E','E','C','B','A','A','A')
  }
  grade
}

mark2grade.v4(90)
mark2grade.v4(80)
mark2grade.v4(70)
mark2grade.v4(60)
mark2grade.v4(50)
mark2grade.v4(0)
mark2grade.v4(100)
mark2grade.v4(123)
mark2grade.v4(-123)


# The data fram representing student marks
names <- c("John","Jack","Mary","Julia")
marks <- c(95, 75, 64, 46)
students <- data.frame(names, marks)
