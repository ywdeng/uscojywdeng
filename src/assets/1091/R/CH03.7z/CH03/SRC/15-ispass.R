is.pass <- function(marks, type = "college") {
  threshold <- ifelse(type == "graduate", 70, 60)
  ifelse(marks >= threshold, TRUE, FALSE)
}

is.pass(c(50L,60L,70L,80L,NA))
is.pass(c(50L,60L,70L,80L,NA),"graduate")
is.pass(c(50L,60L,70L,80L,NA),"college")
is.pass(c(50L,60L,70L,80L,NA),c("college","college","graduate","graduate","graduate"))
is.pass(c(50L,60L,70L,80L,NA),c("graduate","graduate","college","college","college"))