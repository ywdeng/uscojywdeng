setwd("D:/R/CH03/SRC")
deck <- read.csv("data/deck.csv", stringsAsFactors=TRUE)

# 洗過的牌放在 card.env 之中
shuffle <- function(deck) {
    .env <- new.env(parent = globalenv())
    assign("card.env", .env, envir=globalenv())
    .n <- length(deck$face)
    .random <- sample(1:.n, size = .n)
    .env$deck <- deck[.random, ]
    .env$deck
}

# 從 card.env 發牌，發一張少一張
deal <- function() {
    .deck <- card.env$deck
    .card <- .deck[1, ]
    assign("deck", .deck[-1,], envir=card.env)
    .card
}

