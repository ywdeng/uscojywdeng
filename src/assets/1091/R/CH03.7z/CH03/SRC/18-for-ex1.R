setwd("D:/R/CH03/SRC/data")
cls.a201 <- read.csv("A201.CSV", fileEncoding = "utf-8")

# x is the given data.frame
# idx.col is the index of target column
find.max <- function(x, idx.col) {
    m.val <- -Inf   # 世上最小的數字
    m.idx <- 0
    for (r in 1:nrow(x)) {
        n <- x[r, idx.col]
        if (n > m.val) {
            m.val = n
            m.idx = r
        }
    }
    return(x[m.idx,])
}

# 如何找出數學成績最高的同學？
find.max(cls.a201, 5)

# x is the given data.frame
summarize <- function(x) {
    h <- nrow(x) #高度,資料筆數
    w <- ncol(x) #寬度,欄位數量
    
    # data.frame 增加一欄 總成績
    total <- c(1:h)
    cn <- colnames(x)    # 原有欄位名稱
    x <- cbind(x, total) # 增加一欄
    colnames(x) <- c(cn, "總成績")
    for (r in 1:h) {
        x[r,w+1] <- sum(x[r,3:w])
    }
    
    # data.frame 增加一欄 排名
    rnk <- rank(100 - x[,w+1], ties.method= "min")
    cn <- colnames(x)    # 原有欄位名稱
    x <- cbind(x, rnk) # 增加一欄
    colnames(x) <- c(cn, "名次")
    
    return(x)
}

# 如何計算每一位同學的總成績與排名？
final <- summarize(cls.a201)

# 如何列出總成績最高的前三名？
odr <- order(final[,8], decreasing = TRUE)
ss <- final[odr,]
head(ss, 3)

# 有人因為總成績相同而排在同一個名次嗎？如何列出同名次的同學？
prev <- -1
state <- 0
selected <- rep(FALSE, nrow(ss)) # a vector of 50 FALSE
for (r in 1:nrow(ss)) {
    this <- ss[r,8]
    if (state == 0) {
        if (prev == this) {
            selected[r-1] <- TRUE
            selected[r] <- TRUE
            state <- 1
        }
    } else {
        if (prev == this) {
            selected[r] <- TRUE
        } else {
            state <- 0
        }
    }
    prev <- this
}
ss[selected,]

# 鑑於同分者名次相同： head(ss,3) 應該改成：
# 列出總成績最高的前三名：
ss[ss[,9] <= 3,]


