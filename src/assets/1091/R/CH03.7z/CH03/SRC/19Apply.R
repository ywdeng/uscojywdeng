student.marks <- matrix(c(70L,75L,72L,80L,50L,
                          80L,85L,60L,72L,88L,
                          60L,70L,87L,55L,90L,
                          85L,70L,74L,86L,78L),
                          ncol=5,nrow=4,byrow=TRUE)

rownames(student.marks) <- c("Andy","Ben","Ruby","Susan")
colnames(student.marks) <- 
  c("Physics","Chemistry","Mathematics", "Biology","History")
student.marks

# 以迴圈計算每一個學生的總成績
result <- vector("numeric",length=nrow(student.marks))
for(row in 1:nrow(student.marks)){
  sum <- 0
  for(column in 1:ncol(student.marks)){
    sum <- sum + student.marks[row,column]
  }
  result[row] <- sum
}
result

# 以 apply 計算每一個學生的總成績
apply(student.marks,1,sum)

# 每一個學生各種科目最高分數
apply(student.marks,1,max)

# 每一個學生的最高分出現在何處？
apply(student.marks,1,which.max)

# 每一個學生的最高分的科目名稱
colnames(student.marks)[apply(student.marks,1,which.max)]

# 各科平均分數
apply(student.marks,2,mean)

# 各科最高分數
apply(student.marks,2,max)

# 各科最高分的學生是誰？
rownames(student.marks)[apply(student.marks,2,which.max)]

# 所有的學生每一門科目全部加 2 分
apply(student.marks,1:2,function(x) { x + 2 })