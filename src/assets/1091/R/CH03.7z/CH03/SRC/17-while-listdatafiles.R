

# data.files <- c("A171.CSV","A172.CSV","A181.CSV","A182.CSV","A183.CSV","A191.CSV","A192.CSV","A201.CSV","A202.CSV","A203.CSV")

setwd("D:/R/CH03/SRC/data")

data.files <- list.files(path = ".", 
                         pattern = "^A[[:digit:]]{3}.*CSV$")

n <- 0  # �q�Y�}�l
while (n < length(data.files)) {
    n = n + 1   # �U�@��
    print(data.files[n])
}

