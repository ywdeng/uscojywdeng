student.marks <- matrix(c(60L,55L,62L,50L,50L,
                          90L,95L,98L,85L,88L,
                          60L,70L,80L,60L,65L,
                          85L,70L,74L,86L,78L),
                          ncol=5,nrow=4,byrow=TRUE)

rownames(student.marks) <- c("Andy","Ben","Ruby","Susan")
colnames(student.marks) <- 
  c("Physics","Chemistry","Mathematics", "Biology","History")
student.marks
course <- data.frame(Credit=c(3L,3L,4L,2L,2L),
  row.names = c("Physics","Chemistry","Mathematics", "Biology","History"))

final <- apply(student.marks, 1, function(x) sum(x*course[1])/sum(course[1]))
final <- round(final, digits = 0)
student.marks <- cbind(student.marks[,1:5],Final=final)
student.marks

mark2grade.v4 <- function(mark) {
  if (mark < 0 || mark > 100) {
    grade <- 'X'
  } else {
    grade <- switch((mark %/% 10) + 1, 
         'E','E','E','E','E','E','C','B','A','A','A')
  }
  grade
}

grade <- sapply(student.marks[,6], mark2grade.v4)
result <- data.frame(student.marks[,1:6], Grade=grade)
result

course$Min <- apply(student.marks[,1:5],2,min)
course$Average <- apply(student.marks[,1:5],2,mean)
course$Max <- apply(student.marks[,1:5],2,max)
course$Top <- rownames(student.marks)[apply(student.marks[,1:5],2,which.max)]
course
