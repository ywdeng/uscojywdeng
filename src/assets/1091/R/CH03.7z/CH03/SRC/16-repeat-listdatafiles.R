setwd("D:/R/CH03/SRC/data")

# data.files <- c("A171.CSV","A172.CSV","A181.CSV","A182.CSV","A183.CSV","A191.CSV","A192.CSV","A201.CSV","A202.CSV","A203.CSV")

data.files <- list.files(path = ".", 
                         pattern = "^A[[:digit:]]{3}.*CSV$")

n <- 1  # �q�Ĥ@�Ӷ}�l
repeat {
    print(data.files[n])
    n = n + 1   # �U�@��
    if (n > length(data.files)) {
        break   # �W�L�̫�@�ӤF
    }
}

