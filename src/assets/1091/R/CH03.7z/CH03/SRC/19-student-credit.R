# 匯入資料
file <- file.path("Midterm","SRC","student-credit.csv")
stu.report <- read.csv(file)

# 不重複的學生名清單
stu.names <- unique(stu.report$name)
stu.names <- as.vector(stu.names)

# 計算每一個學生獲得的總學分
stu.pass <- vector()
for (name in stu.names) {
	r <- stu.report[stu.report$name == name,]
	n <- sum(r$pass)
	stu.pass <- c(stu.pass, n)
}

# 把學生名和總學分合在一起
stu.credits <- data.frame(stu.names, stu.pass)
stu.credits

# 找出總學分數最高的學生
stu.names[which.max(stu.pass)]

# 排序後發現總學分數最高的學生有兩名
stu.credits[order(stu.credits[2]),]

# 使用 aggregate 就不必自己寫迴圈!
credits.pass <- aggregate(stu.report$pass, by = list(stu.report$name), sum)
credits.pass

colnames(credits.pass) <- c("Name", "Credit")
credits.pass[order(-credits.pass[,2]),] # 負號：反序

# 列出總學分數最高的學生們
tcs <- credits.pass$Name[credits.pass$Credit == max(credits.pass$Credit)]
as.vector(tcs)
