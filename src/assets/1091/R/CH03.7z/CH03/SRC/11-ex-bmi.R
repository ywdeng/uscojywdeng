w <- readline(prompt="體重(公斤):")
h <- readline(prompt="身高(公尺):")
bmi <- as.numeric(w) / as.numeric(h)**2
if (bmi < 18.5) {
    print("過輕")
} else if (bmi < 24) {
    print("正常")
} else if (bmi < 27) {
    print("過重")
} else {
    print("肥胖")
}
