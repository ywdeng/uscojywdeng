setwd("D:/R/CH03/SRC")
deck <- read.csv("data/deck.csv", stringsAsFactors=TRUE)
View(deck)

# 洗牌
shuffle <- function(cards) {
    random <- sample(1:52, size = 52)
    cards[random, ]
}

# 發牌
deal <- function(cards) {
    x <- cards[1, ]
    rownames(x) <- NULL
    print(x)		# 發牌輸出
	cards[-c(1),]	# 移除發過的牌
}

my.cards <- shuffle(deck)	# 洗牌

my.cards <- deal(my.cards)	# 發牌
my.cards <- deal(my.cards)	# 發牌