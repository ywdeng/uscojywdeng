score <- readline(prompt="請輸入成績:")
type <- readline(prompt="身份:1=碩士,2=學士:")

threshold <- ifelse(as.integer(type) == 1, 70, 60)
result <- ifelse(score < threshold, "不及格", "及格")
print(result)