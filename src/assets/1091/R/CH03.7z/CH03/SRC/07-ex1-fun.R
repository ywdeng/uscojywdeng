is.pass <- function(score, threshold) {
    if (score < threshold) {
        return("不及格")
    }
    return("及格")
}

score <- readline(prompt="請輸入成績:")
type <- readline(prompt="身份:1=碩士,2=學士:")

if (type == '1') {
    result <- is.pass(score, 70L)
} else {
    result <- is.pass(score, 60L)
}
print(result)
