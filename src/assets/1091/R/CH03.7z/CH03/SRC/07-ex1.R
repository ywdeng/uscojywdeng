score <- readline(prompt="請輸入成績:")
type <- readline(prompt="身份:1=碩士,2=學士:")
if (type == '1') {
    if (score < 70) {
        print("不及格")
    } else {
        print("及格")
    }
} else {
    if (score < 60) {
        print("不及格")
    } else {
        print("及格")
    }
}

if (((type == '1') && (score < 70)) || ((type != '2') && (score < 60))) {
    print("不及格")
} else {
    print("及格")
}

