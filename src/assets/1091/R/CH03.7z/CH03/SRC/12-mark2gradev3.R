# A scalar function converts percentage mark to grade
mark2grade.v3 <- function(mark) {
  if (mark < 0 || mark > 100) {
    grade <- 'X'
  } else {
    grade <- switch(as.character(mark %/% 10),
      '10' = 'A',
      '9' = 'A',
      '8' = 'A',
      '7' = 'B',
      '6' = 'C',
      '5' = 'D',
      'E'
    )
  }
  grade
}

mark2grade.v3(90)
mark2grade.v3(80)
mark2grade.v3(70)
mark2grade.v3(60)
mark2grade.v3(50)
mark2grade.v3(0)
mark2grade.v3(100)
mark2grade.v3(123)
mark2grade.v3(-123)

