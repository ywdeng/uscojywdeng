# 取較大的值
a <- 100
b <- 101

if (a > b) {
    max <- a
} else {
    max <- b
}

max <- ifelse(a > b, a, b)