vmode <- function(v) {
    uniqv <- unique(v)
	freq <- tabulate(match(v, uniqv))
	max.count <- max(freq)
    result <- uniqv[freq == max.count]
	as.vector(result)
}

library(babynames)

# 女嬰
babygirls <- babynames[babynames$sex == 'F',]

# 男嬰
babyboys <- babynames[babynames$sex == 'M',]

# 出現次數最頻繁的嬰兒名
freq.names <- vmode(babynames$name)

# 出現次數最頻繁的女嬰兒名
freq.girlnames <- vmode(babygirls$name)

# 出現次數最頻繁的男嬰兒名
freq.boynames <- vmode(babyboys$name)

# 女嬰名和男嬰名的交集：出現次數最頻繁的嬰兒名
intersect(freq.girlnames, freq.boynames)

#################################################################
# 以下只考慮 2000 年之後出生的嬰兒
baby2k <- babynames[babynames$year >= 2000,]

# 計算每一個名字的使用人口數
baby2k.aggr <- aggregate(baby2k$n, by = list(baby2k$name), FUN = sum)
head(baby2k.aggr)
colnames(baby2k.aggr) <- c("Name", "Population")

# 最多人使用的嬰兒名字
baby2k.most.name <- baby2k.aggr$Name[which.max(baby2k.aggr$Population)]
baby2k.most.name

# 以人口數遞減排列，檢查最多人使用的名字是否唯一
head(baby2k.aggr[order(-baby2k.aggr[,2]),])

# 把上述動作寫成 function
popular.names <- function(x) {
	aggr <- aggregate(x$n, by = list(x$name), FUN = sum)
	colnames(aggr) <- c("Name", "Population")
	# print(head(aggr[order(-aggr[,2]),]))
	aggr$Name[aggr$Population == max(aggr$Population)]
}

# 最多人使用的女性嬰兒名
popular.names(baby2k[baby2k$sex == 'F',])

# 最多人使用的男性嬰兒名
popular.names(baby2k[baby2k$sex == 'M',])




