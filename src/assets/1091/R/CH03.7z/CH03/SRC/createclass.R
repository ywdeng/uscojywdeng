create.class <- function(id.prefix, class.size=60, range=1:100) {
	.myclass <- data.frame(create.ids(id.prefix), 
						student.names[range], 
						student.mark1[range],
						student.mark2[range],
						student.mark3[range],
						student.mark4[range],
						student.mark5[range],
						row.names = NULL
	)
	colnames(.myclass) <- c("SID","A","B","C","D","E","F")
	.myclass <- .myclass[sample(1:nrow(.myclass),class.size),]
	.myclass <- .myclass[order(.myclass$SID),]
	
	colnames(.myclass) <- c("學號","姓名","國文","英文","數學","自然","社會")
	row.names(.myclass) <- NULL
	
	.myclass
}	

save.class <- function(x, filename) {
	write.table(x, file = filename, append = FALSE, quote = TRUE, sep = ",",
            eol = "\n", na = "NA", dec = ".", row.names = FALSE,
            col.names = TRUE, qmethod = c("escape", "double"),
            fileEncoding = "UTF-8")
}
			