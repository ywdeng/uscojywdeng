integer.divide <- function(dividend, divisor) {
  q = dividend %/% divisor
  r = dividend %% divisor
  c(quotient=q,remainder=r)
}
integer.divide(100, 7)
body(integer.divide)
environment(integer.divide)
formals(integer.divide)
