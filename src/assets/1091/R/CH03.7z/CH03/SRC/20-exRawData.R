andy <- c(60L,55L,62L,50L,50L)
ben <- c(90L,95L,98L,85L,88L)
ruby <- c(60L,70L,80L,60L,65L)
susan <- c(85L,70L,74L,86L,78L)
student.names <- c("Andy","Ben","Ruby","Susan")
course.credit <- c(3L,3L,4L,2L,2L)
course.names <- 
 c("Physics","Chemistry","Mathematics", "Biology","History")