# 練習：幾何計算

r <- 10
L = 2 * pi * r; L
A = pi * r^2; A

a <- 45
L <- 2 * pi * r * a / 360; L
A <- pi * r^2 * a / 360; A
