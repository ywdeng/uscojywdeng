store1.sales.apple <- c(90L,95L,90L,85L)
store1.sales.banana <- c(100L,80L,75L,70L)
store1.sales.fig <- c(60L,120L,100L,150L)
store1.sales=rbind(store1.sales.apple,store1.sales.banana,store1.sales.fig)
store1.sales
store2.sales.apple <- c(200L,200L,210L,200L)
store2.sales.banana <- c(80L,75L,70L,65L)
store2.sales.fig <- c(50L,60L,70L,80L)
store2.sales=rbind(store2.sales.apple,store2.sales.banana,store2.sales.fig)
store2.sales
sales = array(c(store1.sales,store2.sales),dim=c(3,4,2))
colnames(sales) <- c("Q1","Q2","Q3","Q4")
rownames(sales) <- c("Apple","Banana","Fig")
dimnames(sales)[[3]] <- c('Store1','Store2')
sales