match.score <- 300 #Using assignment operator
match.score #print variable content
assign("match.score",300) #Using assign function
match.score #print variable content