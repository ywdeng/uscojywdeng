student.names <- c("John","Jack","Mary","Julia")
student.weights <- c(60.5,72.5,45.2,47.5)
student.genders <- factor(c("Male","Male","Female","Female"))
student.physics.marks <- c(70L,75L,80L,85L)
student.chemistry.marks <- c(60L,70L,85L,70L)

#Creating unnamed list
student1 <- list(student.names[1],student.weights[1],
                 student.genders[1],student.physics.marks[1],
                 student.chemistry.marks[1])
str(student1)
student1

#Subsetting: Extract element(s) from unnamed list
#Single brackets [] return element of the same type
student1[1] 
typeof(student1[1]) #list

#double brackets [[]] return the object in its own type
student1[[1]] 
typeof(student1[[1]]) #character

student1[1:3] #Access multiple elements using index

