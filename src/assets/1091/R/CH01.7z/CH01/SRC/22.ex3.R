die <- 1:6 # 骰子點數 1,2,3,4,5,6
roll <- sample(die, 2, replace=TRUE) # 2 顆骰子，可重複
sum(roll) # 點數加總