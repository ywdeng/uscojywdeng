# 練習：解一元二次方程式

a <- 1
b <- 2
c <- -3
(-b + sqrt(b^2 - 4*a*c))/(2*a)
(-b - sqrt(b^2 - 4*a*c))/(2*a)


a <- 1/2
b <- -6
c <- 11/2
(-b + sqrt(b^2 - 4*a*c))/(2*a)
(-b - sqrt(b^2 - 4*a*c))/(2*a)



##繪製曲線 y = x^2 + 2x - 3
##資料點
a <- 1
b <- 2
c <- -3
x <- seq(-4,2,by=0.01)
f1 <- function(x,a,b,c) a*x^2 + b*x + c
y <- f1(x, a, b, c)
df <- data.frame(x,y)

##用ggplot2繪圖
library(ggplot2)
g <- ggplot(df,aes(x,y))
g <- g+geom_line(col='red')   #紅色曲線
g <- g+geom_hline(yintercept=0)+geom_vline(xintercept=0)
g <- g+ggtitle(paste("y=",a,"x^2+",b,"*x+",c))
g



##繪製曲線 y = 1/2 x^2 - 6x + 11/2
##資料點
a <- 1/2
b <- -6
c <- 11/2
x <- seq(-1,13,by=0.01)
f2 <- function(x,a,b,c) a*x^2 + b*x + c
y <- f2(x, a, b, c)
df <- data.frame(x,y)

##用ggplot2繪圖
library(ggplot2)
g <- ggplot(df,aes(x,y))
g <- g+geom_line(col='red')   #紅色曲線
g <- g+geom_hline(yintercept=0)+geom_vline(xintercept=0)
g <- g+ggtitle(paste("y=",a,"x^2+",b,"*x+",c))
g