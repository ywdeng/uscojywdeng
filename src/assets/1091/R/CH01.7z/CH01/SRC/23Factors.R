student.names <- c("John","Jack","Mary","Julia")
# use character vector to represent gender
student.genders <- c("Male","Male","Female","Female") 
student.genders
# integers are more efficient than strings
student.genders <- c(1L,1L,0L,0L) # Integer vector
student.genders

# using factor
student.genders <- factor(c("Male","Male","Female","Female"))
student.genders
as.numeric(student.genders) #Explicit conversion

student.blood <- factor(c("A","AB","O","AB"), levels = c("A","B","AB","O")) 
str(student.blood)

# use gl() to generate factor levels
student.marriage <- gl(3,1,4,labels=c("Single","Engaged","Married"))
student.marriage

# use match() to find element in vector
student.marriage[match("Mary",student.names)]="Engaged"
student.marriage

