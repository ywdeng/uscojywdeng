setwd("D:/2020/USC/1091/R/CH01/SRC")
install.packages("png")
library(png)

apple.png <- readPNG("../apple.png")
grid::grid.raster(apple.png)

install.packages("jpeg")
library(jpeg)
banana.jpg <- readJPEG("../banana.jpg")
grid::grid.raster(banana.jpg)