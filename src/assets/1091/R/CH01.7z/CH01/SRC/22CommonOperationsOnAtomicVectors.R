#Peforming arithmetic and logical operation on atomic vectors
student.physics.marks <- c(70L,75L,80L,85L)
student.chemistry.marks <- c(60L,70L,85L,70L)
#arithmetic operation
student.physics.marks + student.chemistry.marks 
#logical operation
student.physics.marks >= 75 

#Extract element(s) from atomic vectors (Subsetting)
student.names <- c("John","Jack","Mary","Julia")
student.names[1] #1 based index, use [] to access elements
student.names[2] #Extract second element
student.names[1:3] #Extract multiple elements
#Extract multiple elements by specifying a logical vector
student.names[c(T,F,T,F)] 
student.names[student.physics.marks >= 75]

#Coercions : converting one type to another
#Implicit Coercions
student.weights <- c(60.5,72.5,45.2,"47.5")
str(student.weights)

#Explicit Coercions
#Sensible Coercions
# Coverting logical values to numeric values
as.numeric(student.physics.marks >= 75) 
# Coverting integer values to character values
as.character(student.physics.marks) 
student.weights <- c(60.5,72.5,45.2,47.5) #Numeric(double) vector
as.integer(student.weights)

#Coercions which are not sensible
as.numeric(student.names) #Converting names to numeric values