student.physics.marks <- c(70L,75L,80L,85L)
student.chemistry.marks <- c(60L,70L,85L,70L)
# rbind: row binding
student.marks <- rbind(student.physics.marks,
                       student.chemistry.marks)
student.marks
colnames(student.marks) <- c("John","Jack","Mary","Julia")
rownames(student.marks) <- c("physics","chemistry")
student.marks
str(student.marks)

# cbind: column binding
student.marks <- cbind(student.physics.marks,
                       student.chemistry.marks)
student.marks
rownames(student.marks) <- c("John","Jack","Mary","Julia")
colnames(student.marks) <- c("physics","chemistry")
student.marks
str(student.marks)

# create matrix by rows
student.marks <- matrix(c(70L,75L,80L,85L,60L,70L,85L,70L),
                        ncol=4,nrow=2,byrow=TRUE)
colnames(student.marks) <- c("John","Jack","Mary","Julia")
rownames(student.marks) <- c("physics","chemistry")                        
student.marks
str(student.marks)

# create matrix by columns
# dimnames is NULL or a list of length 2 
#          giving the row and column names respectively
student.marks <- matrix(c(70L,75L,80L,85L,60L,70L,85L,70L),
        ncol=2,nrow=4,
        dimnames=list(c("John","Jack","Mary","Julia"),
                      c("physics","chemistry")))
student.marks
str(student.marks)
