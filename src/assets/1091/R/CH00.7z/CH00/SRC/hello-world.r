#This is comment 註解
print("Hello world!") # print to the console
s <- 1:20 #use of variable: x gets a sequence of numbers from 1 to 20
print(s)
m <- mean(s) #compute the mean of a sequence of numbers
print(m)