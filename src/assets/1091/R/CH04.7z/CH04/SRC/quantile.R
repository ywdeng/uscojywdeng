v <- c(1,2,2,3,3,3,4,4,4,5,5,5,5,6,6,6,6,6,6,6,9,9,9,9)
quantile(v)
q1 <- quantile(v,0.25); q1
q3 <- quantile(v,0.75); q3
as.numeric(q3 - q1)
IQR(v)
