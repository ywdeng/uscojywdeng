setwd("D:/R/CH04/SRC")  # set working directory
A10 <- read.table(file="grade.csv",header=TRUE,sep=",",encoding="UTF-8")
str(A10)
M10 <- as.matrix(A10)   # Data Frame 轉 Matrix 去除 header
X<-M10[,2]              # 自變數
Y <- M10[,3]            # 因變數
lm.model <- lm(Y ~ X)   # Fitting Linear Models
lm.model
cf <- coef(lm.model)    # 迴歸係數
cf
lm.function <- function(x) { 
    y <- cf[1] + cf[2]*x 
}

Y.output <- sapply(X, lm.function)
Y.output
abs(Y-Y.output)         # 誤差越小表示模型越準

plot(X,Y,xlab="每週自習時數",ylab="考試成績") # 分布圖
abline(lm.model)        # 線性模型
points(X,Y.output,col="blue")