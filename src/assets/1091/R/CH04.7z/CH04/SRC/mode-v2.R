vmode <- function(v) {
    uniqv <- unique(v)
    uniqv[which.max(tabulate(match(v, uniqv)))]
}

vmode(quakes$mag) # 出現次數最頻繁的地震規模

install.packages("babynames")
library(babynames)
vmode(babynames$name[babynames$sex == 'F']) # 出現次數最頻繁的女嬰名
vmode(babynames$name[babynames$sex == 'M']) # 出現次數最頻繁的男嬰名

