if (!require(corrplot)) {
    install.packages("corrplot")    
    library(corrplot)
}    
head(quakes)
cor_matrix <- cor(quakes)
sig_test <- cor.mtest(quakes, conf.level = 0.95)
corrplot.mixed(cor_matrix, p.mat = sig_test$p, sig.level = 0.05, lower.col = "black")