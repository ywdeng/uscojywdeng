# draw a smooth line through a scatter plot
plot(cars, main = "Stopping Distance versus Speed")
p <- stats::lowess(cars)
p
lines(p)
