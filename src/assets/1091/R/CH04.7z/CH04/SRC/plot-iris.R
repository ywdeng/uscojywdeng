cls <- unique(iris$Species) # distinct class name
plot(iris$Sepal.Length[iris$Species==cls[1]],iris$Petal.Length[iris$Species==cls[1]],
    pch=1,col="black",
    xlim=c(4,8),ylim=c(0,8),
    main="Classified Scatter Plot",xlab="Sepal Length",ylab="Petal Length")
points(iris$Sepal.Length[iris$Species==cls[2]],iris$Petal.Length[iris$Species==cls[2]],
    pch=2,col="red")
points(iris$Sepal.Length[iris$Species==cls[3]],iris$Petal.Length[iris$Species==cls[3]],
    pch=3,col="blue")
legend(4,8,legend=cls, col=c("black","red","blue"), pch=c(1,2,3))
