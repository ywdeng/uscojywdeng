data(quakes)
X <- quakes$mag
Y <- quakes$stations
mymodel <- lm(Y ~ X)
cf <- coef(mymodel)
myfunc <- function(x) { y <- cf[1] + cf[2]*x }
min(quakes$mag); max(quakes$mag)
min(quakes$stations); max(quakes$stations)
plot(c(4,7),c(10,140),type = 'n',xlab="Richter Magnitude",ylab="Number of Stations Reporting")
points(X, Y)
abline(mymodel,col="red")
x.mag = 6.5
y.stations <- myfunc(x.mag)
points(x.mag,y.stations,col="blue",lwd=5)