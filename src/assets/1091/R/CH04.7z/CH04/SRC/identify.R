x <- seq(0,2*pi,by=1/20)
y <- sin(x)
plot(x,y)
pts <- locator(n=7, type="p", col='red', cex=2, lwd=3)
pts
points(pts, col='green', cex=3, lwd=3)
ids <- identify(x,y,labels=c("MIN","MAX"),col="blue")
ids
