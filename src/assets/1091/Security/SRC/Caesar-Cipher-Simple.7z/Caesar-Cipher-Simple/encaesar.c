#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char usage[] =
    " [-k n] [input_file] [output_file]\nWhere n is the shift distance, default value is n=3.";

char lower[26];
char upper[26];
FILE *input;
FILE *output;
int shift = 3;

void init()
{
    int i;
    for (i = 0; i < 26; i++)
    {
        lower[i] = (char)('a' + i);
        upper[i] = (char)('A' + i);
    }
}

char encLower(char c)
{
    int x = c - 'a';
    x = (x + shift) % 26;
    return lower[x];
}

char encUpper(char c)
{
    int x = c - 'A';
    x = (x + shift) % 26;
    return upper[x];
}

int main(int argc, char *argv[])
{
    char c;
    int n = 1;
    input = stdin;
    output = stdout;
    if (argc > 1)
    {
        if ((strcmp(argv[1], "-k") == 0) && (argc > 2))
        {
            shift = atoi(argv[2]);
            n = 3;
        }
    }
    if (argc > n)
    {
        input = fopen(argv[n], "r");
        if (!input)
        {
            fprintf(stderr, "Can not open input file %s !\n", argv[n]);
            fprintf(stderr, "Usage:\n%s%s", argv[0], usage);
            exit(-1);
        }
        n++;
    }
    if (argc > n)
    {
        output = fopen(argv[n], "w");
        if (!output)
        {
            fprintf(stderr, "Can not open output file %s !\n", argv[n]);
            fprintf(stderr, "Usage:\n%s%s", argv[0], usage);
            exit(-2);
        }
    }
    init();
    c = fgetc(input);
    while (!feof(input))
    {
        if ((c >= 'A') && (c <= 'Z'))
        {
            fputc(encUpper(c), output);
        }
        else if ((c >= 'a') && (c <= 'z'))
        {
            fputc(encLower(c), output);
        }
        else
        {
            fputc(c, output);
        }
        c = fgetc(input);
    }
    fclose(input);
    fclose(output);
}
