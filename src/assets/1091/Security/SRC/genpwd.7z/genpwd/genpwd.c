#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char *in_array;
int in_width = 0;
int out_width = 0;

void perr(char *pname, int n)
{
    fprintf(stderr,
            "%s is a password generator for brute force attack.\n", pname);
    fprintf(stderr,
            "Usage:\n%s [-n width] list-of-permutation-characters\n", pname);
    fprintf(stderr,
            "\n-n width specifies the width of the generated password.\n");
    exit(n);
}

void permu(char *result, int curr_len, int next_idx)
{
    if (curr_len >= out_width)
    {
        printf("%s\n", result);
        return;
    }
    while (next_idx < in_width)
    {
        result[curr_len] = in_array[next_idx];
        permu(result, curr_len + 1, 0);
        next_idx++;
    }
}

int main(int argc, char *argv[])
{
    int n = 1;
    char *result;
    if (argc <= n)
    {
        perr(argv[0], -1);
    }
    if (strcmp(argv[1], "-n") == 0)
    {
        out_width = atoi(argv[2]);
        n = 3;
    }
    if (argc <= n)
    {
        perr(argv[0], -2);
    }
    in_array = argv[n];
    in_width = strlen(in_array);
    if (out_width < 1)
        out_width = in_width;
    result = (char *)calloc(out_width + 1, sizeof(char));
    permu(result, 0, 0);
    free(result);
}
