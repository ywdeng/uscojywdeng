#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[])
{
    unsigned int my_seed;
    int count = 10, ok = 0, i;
    if ((argc > 2) && (strcmp(argv[1], "-s") == 0))
    {
        my_seed = atoi(argv[2]);
        ok = 1;
    }
    if (argc == 4)
    {
        count = atoi(argv[3]);
        ok = (count > 0);
    }
    
    if (!ok)
    {
        fprintf(stderr, "Pseudo random number generator."
                        "Usage:\n\n%s -s seed [count]\n\n"
                        "Where seed is the random seed and count is the number of random number generated.\n",
                argv[0]);
        return -1;
    }

    srand(my_seed);

    fprintf(stderr, "Generating %d random numbers with seed %u:\n", count, my_seed);

    for (i = 0; i < count; i++)
    {
        printf("%u\n", rand());
    }
    return 0;
}
