#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[])
{
    int count = 10, ok = 0, i;
    if (argc == 2)
    {
        count = atoi(argv[1]);
        ok = (count > 0);
    }
    else
        ok = (argc == 1);

    if (!ok)
    {
        fprintf(stderr, "Pseudo random number generator,"
                        "Usage:\n\n%s [count]\n\n"
                        "Where count is the number of random number generated.\n",
                argv[0]);
        return -1;
    }
    
    unsigned int my_seed = (unsigned int)time(NULL);
    srand(my_seed);

    fprintf(stderr, "Generating %d random numbers with seed %u:\n", count, my_seed);

    for (i = 0; i < count; i++)
    {
        printf("%u\n", rand());
    }
    return 0;
}
