/*
 * Base64 encoding/decoding (RFC1341)
 * Copyright (c) 2005, Jouni Malinen <j@w1.fi>
 *
 * This software may be distributed under the terms of the BSD license.
 * See README for more details.
 */

#ifndef CAESARCODEC_H
#define CAESARCODEC_H

void caesar_init();
unsigned char caesar_encode(const unsigned char src, int shift);
unsigned char caesar_decode(const unsigned char src, int shift);

#endif /* CAESARCODEC_H */
