#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "base64.h"
#include "caesarcodec.h"

#define BUF_SIZE 65536

#define DEBUG 0

const char usage[] =
    " [-k n] [input_file] [output_file]\nWhere n is the shift distance, default value is n=3.";

FILE *input;
FILE *output;
static int shift = 3;
unsigned char *buf = NULL;
int buf_len = 0;
unsigned char *base64buf = NULL;
size_t base64buf_len = 0;

void init()
{
    caesar_init();
    buf = (unsigned char *)calloc(sizeof(unsigned char), BUF_SIZE);
    buf_len = 0;
}

void cleanup()
{
    if (base64buf)
        free(base64buf);
    if (buf)
        free(buf);
}

int main(int argc, char *argv[])
{
    char c;
    int i, n = 1;
    input = stdin;
    output = stdout;
    if (argc > 1)
    {
        if ((strcmp(argv[1], "-k") == 0) && (argc > 2))
        {
            shift = atoi(argv[2]);
            n = 3;
        }
    }
    if (argc > n)
    {
        input = fopen(argv[n], "r");
        if (!input)
        {
            fprintf(stderr, "Can not open input file %s !\n", argv[n]);
            fprintf(stderr, "Usage:\n%s%s", argv[0], usage);
            exit(-1);
        }
        n++;
    }
    if (argc > n)
    {
        output = fopen(argv[n], "w");
        if (!output)
        {
            fprintf(stderr, "Can not open output file %s !\n", argv[n]);
            fprintf(stderr, "Usage:\n%s%s", argv[0], usage);
            exit(-2);
        }
    }
    init();
    c = fgetc(input);
    while (!feof(input) && (buf_len < BUF_SIZE))
    {
        buf[buf_len] = c;
        buf_len++;
        c = fgetc(input);
    }
    fclose(input);
    if (buf_len > 0)
    {
        base64buf = base64_encode(buf, buf_len, &base64buf_len);
        if (base64buf)
        {
#if DEBUG
            printf("BASE64 SIZE %d:\n", (int)base64buf_len);
            puts(base64buf);
#endif
            for (i = 0; i < base64buf_len; i++)
            {
                fputc(caesar_encode(base64buf[i], shift), output);
            }
        }
    }

    fclose(output);
    cleanup();
}
