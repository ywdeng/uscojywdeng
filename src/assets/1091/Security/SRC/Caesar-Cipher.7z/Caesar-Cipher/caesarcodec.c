#include <string.h>
#include <stdlib.h>
#include "base64.h"
#include "caesarcodec.h"

#define EQUALS_REPLACE '-'

#define REV_TABLE_SIZE 256
const unsigned char *src_table;

static int rev_table[REV_TABLE_SIZE];

void caesar_init()
{
    int i, n;
    src_table = get_base64_table();
    memset(rev_table, 0, sizeof(int) * REV_TABLE_SIZE);
    for (i = 0; i < BASE64_TABLE_SIZE; i++)
    {
        n = src_table[i] & 0xFF;
        rev_table[n] = i;
    }
}

unsigned char shift_code(const unsigned char src, int shift)
{
    int pos = rev_table[src] + shift;
    if (pos >= BASE64_TABLE_SIZE)
    {
        pos = pos % BASE64_TABLE_SIZE;
    }
    else
    {
        while (pos < 0)
        {
            pos += BASE64_TABLE_SIZE;
        }
    }
    return src_table[pos];
}

unsigned char caesar_encode(const unsigned char src, int shift)
{
    if (src == '=')
    {
        return EQUALS_REPLACE;
    }
    if ((src == '\n') || (src == '\r'))
    {
        return src;
    }
    return shift_code(src, shift);
}

unsigned char caesar_decode(const unsigned char src, int shift)
{
    if (src == EQUALS_REPLACE)
    {
        return '=';
    }
    if ((src == '\n') || (src == '\r'))
    {
        return src;
    }
    return shift_code(src, -1 * shift);
}