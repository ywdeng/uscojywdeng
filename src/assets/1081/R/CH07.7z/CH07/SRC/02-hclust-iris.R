# 7-2

data(iris)
data.input <- iris[,1:4]

# using dd.clustlust() and single linkage
# dist() computes the distance matrix
data.dist <- dist(data.input, method = "euclidean")
dd.clust <- hclust(data.dist, method = "ward.D2")

plot(dd.clust)

rect.hclust(dd.clust, k=3)

# 分成三群
dd.3 <- cutree(dd.clust, k=3)  
# 分群結果
dd.3                           

# 比較實際結果與分群結果
table(iris$Species, dd.3)

# 分群結果不佳，查看資料分佈狀況
par(mfrow = c(2,2))
plot(iris$Petal.Width, iris$Petal.Length, col = c(1:3)[unclass(iris$Species)], pch = 15)
plot(iris$Sepal.Width, iris$Sepal.Length, col = c(1:3)[unclass(iris$Species)], pch = 15)

pairs(iris[1:4], main = "Edgar Anderson's Iris Data", pch = 21, bg = c("red", "green3", "blue")[unclass(iris$Species)])

			 