# 7-1
data(iris)
index <- 1:nrow(iris)
np <- ceiling(0.1 * nrow(iris))
idx <- sample(1:nrow(iris), np)
irisSample <- iris[idx,]

# remove labels
irisSample$Species <- NULL

# using hclust() and single linkage
# dist() computes the distance matrix
hc <- hclust(dist(irisSample), method = "single")

plot(hc, labels=iris$Species[idx])

rect.hclust(hc, k=3)
