require(NbClust)
data(iris)

X <- iris[, -c(5)]
Y <- NbClust(X, distance = "euclidean", min.nc = 2, max.nc = 6, method = "kmeans", index = "all")