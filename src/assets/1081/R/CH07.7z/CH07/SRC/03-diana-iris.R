# install.packages("cluster")
require(cluster) # for diana()

data(iris)

head(iris)

X <- scale(iris[,-5])

# compute divisive hierarchical clustering
Y <- diana(X)

# Divisive coefficient
Y$dc

# plot tree
pltree(Y, cex = 0.6, hang = -1, main = "Dendrogram of DIANA")

# Cut diana() tree into 3 groups
group <- cutree(Y, k = 3)
group

table(iris[,5], group)

# if the factor level number is out-of-order
require(plyr)
yy <- revalue(as.factor(group), c('1'='setosa','2'='virginica','3'='versicolor'))
y <- as.character(yy)
y <- as.factor(y)
table(iris$Species,y)

# Visualize Clustering Results
# install.packages("factoextra")
require(factoextra)
fviz_cluster(list(data = X, cluster = group))