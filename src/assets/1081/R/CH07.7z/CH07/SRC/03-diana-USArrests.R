# install.packages("cluster")
require(cluster) # for diana()

data(USArrests)

head(USArrests)

X <- scale(USArrests)

# compute divisive hierarchical clustering
Y <- diana(X)

# Divisive coefficient
Y$dc

# plot tree
pltree(Y, cex = 0.6, hang = -1, main = "Dendrogram of DIANA")

# Cut diana() tree into 4 groups
group <- cutree(Y, k = 4)
group

# Visualize Clustering Results
# install.packages("factoextra")
require(factoextra)
fviz_cluster(list(data = X, cluster = group))