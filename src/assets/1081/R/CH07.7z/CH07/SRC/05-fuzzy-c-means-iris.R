require(e1071)
data(iris)
attributes(iris)

X <- iris
X$Species <- NULL

Y <- cmeans(X,centers = 3, iter.max = 500, verbose = TRUE, method = "cmeans")
print(Y)
table(iris$Species, Y$cluster)

# rename factor levels if required
require(plyr)
yy <- revalue(as.factor(Y$cluster), c('2'='setosa','3'='versicolor','1'='virginica'))
y <- as.character(yy)
y <- as.factor(y)
table(iris$Species, y)

# 標示各群組的質心
plot(X[c("Sepal.Length","Sepal.Width")], col = Y$cluster, main = "Centroids of Each Cluster")
points(Y$centers[,c("Sepal.Length","Sepal.Width")], col = 1:3, pch = 8, cex = 2, lwd = 3)

# 標示各群組的質心
plot(X[c("Petal.Length","Petal.Width")], col = Y$cluster, main = "Centroids of Each Cluster")
points(Y$centers[,c("Petal.Length","Petal.Width")], col = 1:3, pch = 8, cex = 2, lwd = 3)
