data(iris)
attributes(iris)

X <- iris
X$Species <- NULL

Y <- kmeans(X, 3)
table(iris$Species, Y$cluster)

# 標示各群組的質心
plot(X[c("Sepal.Length","Sepal.Width")], col = Y$cluster, main = "Centroids of Each Cluster")
points(Y$centers[,c("Sepal.Length","Sepal.Width")], col = 1:3, pch = 8, cex = 2, lwd = 3)

# 標示各群組的質心
plot(X[c("Petal.Length","Petal.Width")], col = Y$cluster, main = "Centroids of Each Cluster")
points(Y$centers[,c("Petal.Length","Petal.Width")], col = 1:3, pch = 8, cex = 2, lwd = 3)

# install.packages("factoextra")
require(factoextra)
fviz_cluster(Y,           				# 分群結果
             data = X,        			# 資料
             geom = c("point","text") 	# 點和標籤(point & label)
)