my.data <- scan(file="data/02Sample.txt",
    what=list(name="",gender="",weights=0,
        physics=0L,chemistry=0L),
    skip=2)
my.data
str(my.data)

