#loading the package
require(XLConnect)
 
#creating an Excel workbook
wb <- loadWorkbook("data/12Sample.xlsx",create=TRUE)
 
#creating sheets within an Excel workbook
createSheet(wb,name="IRIS")
 
#writing into sheets within an Excel workbook : 
#writing iris data frame into IRIS
writeWorksheet(wb,iris,sheet="IRIS",startRow=1,startCol=2)
 
#saving a workbook to an Excel file :
#writes the file to disk.
saveWorkbook(wb)