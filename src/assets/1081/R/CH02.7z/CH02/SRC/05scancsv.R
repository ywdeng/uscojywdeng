my.data <- scan(file="data/01Sample.csv",
    sep=",",
    what=list(physics=0L,chemistry=0L),
    skip=1)
my.data
str(my.data)

