# install.packages("mongolite")
library(mongolite)
url <- "mongodb://itmuser:uscpassw0rd@52.23.179.109:27017"
c <- mongo(collection="iris",db="rdatasets",url=url,verbose=TRUE)
c$find() # list all
c$distinct("Species") # find distinct species
c$count() # count the number of records
c$find('{"Species":"versicolor"}') # list Iris-Versicolor only
c$aggregate('[
  {
    "$group":
      {
        "_id":"$Species",
        "Count":{"$sum":1},
        "Average Sepal Length":{"$avg":"$SepalLength"}
      }
  }
]')