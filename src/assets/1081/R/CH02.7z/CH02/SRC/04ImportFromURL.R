url <- "http://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
setwd(file.path("D:","R","CH02","SRC")) 
local <- file.path("data","03DownloadedFile.data")
download.file(url,local)
my.data <- read.table(local,sep=",")
str(my.data)
colnames(my.data) <- c("Sepal Length","Sepal Width",
    "Petal Length","Petal Width","Species")