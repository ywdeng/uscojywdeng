library(datasets)
data(package="datasets")
data(iris)
str(iris)
save(iris,file="data/iris.RData")
iris <- NULL # nullify iris
str(iris)
load("data/iris.RData", .GlobalEnv) # reload iris
str(iris) # check it up
