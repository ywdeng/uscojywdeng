#Set working directory
getwd() #get working directory
setwd("D:\\R\\CH02\\SRC") #windows
setwd("D:/R/CH02/SRC") #windows
setwd("/home/UserName/R/CH02/SRC") #on mac or linux
setwd(file.path("D:","R","CH02","SRC")) 