require(neuralnet) # for neuralnet(), nn model
require(GA)
data(iris)

formu <- (Species == "setosa") + (Species == "versicolor") + (Species == "virginica") ~ Sepal.Length + Sepal.Width + Petal.Length + Petal.Width

fit.fun <- function(vargs) {
	layers <- ceiling(vargs[vargs > 0])
	# print(paste("Hidden Layers:", paste(as.character(layers), collapse = ", ")))	
	model.ann <- model.ann <- neuralnet(formu, 
		data = data.train,
		hidden = layers,
		learningrate = 0.01,  # learning rate
		threshold = 0.01,     # partial derivatives of the error function, a stopping criteria
		stepmax = 5e5         # 最大的ieration數 = 500000(5*10^5)
		)
	pred <- predict(model.ann, data.test)
	specs <- apply(pred, 1, which.max)
	if (length(unique(specs)) != 3) {
		accuracy <- -1
	} else {
		t <- table(data.test$Species, specs)
		accuracy <- 100 * sum(diag(t)) / sum(t)
	}
	if ((exists("accuracy.max") == FALSE) || (accuracy > accuracy.max)) {
		accuracy.max <<- accuracy
		layers.best <<- layers
		model.best <<- model.ann
	}
	return (accuracy)
}

# Split data
index.train <- sample(nrow(iris), 2/3 * nrow(iris))
data.train <- iris[index.train, ]
data.test <- iris[-index.train, ]

ga(type = 'real-valued', fitness = fit.fun, 
	lower = c(1,0,0), upper = c(3,3,3), 
	popSize = 50, pcrossover = 0.8, pmutation = 0.1, 
	elitism = 10, monitor = gaMonitor, maxiter = 20)

print(paste("Best network structure:", paste(as.character(layers.best), collapse = ", ")))
print(paste("Max accuracy:", paste(as.character(accuracy.max), collapse = ", ")))
plot(model.best)