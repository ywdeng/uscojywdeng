
#install.packages("ANN")   �Υ�����zip�ɮרӦw�˵{���M��
library(ANN)

#use the command demo(ANN) to see how dataANN was created
data("dataANN")

#Example
ANNGA(x =input,
y =output,
design =c(1, 3, 1),
population =100,
mutation = 0.3,
crossover = 0.7,
maxGen =100,
error =0.001)


