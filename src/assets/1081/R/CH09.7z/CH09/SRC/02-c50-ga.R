require(C50)
require(GA)
data(iris)

error.fun <- function(vargs) {
	# CF: a number in (0, 1) for the confidence factor.
	# minCases: an integer for the smallest number of samples that must be put in at least two of the splits.
	ctrl <- C5.0Control(subset = FALSE, bands = 0, winnow = FALSE, noGlobalPruning = FALSE, 
		CF = vargs[1] / 100.0, 	
		minCases = floor(vargs[2]), 
		fuzzyThreshold = FALSE, sample = 0, seed = sample.int(4096, size = 1) - 1L, earlyStopping = TRUE
	)
	
	model.tree <- C5.0(x = data.train[, 1:4], y = data.train$Species, control = ctrl)
	summary(model.tree)
	
	test.output <- predict(model.tree, data.test[, 1:4], type = "class")
	
	compare <- test.output == data.test[,5]
	error.count <- sum(sapply(compare, function(x) { if (x == FALSE) 1 else 0 }))	
	error <- error.count / length(compare) * 100
	
	if ((exists("error.min") == FALSE) || (error < error.min)) {
		CF.best <<- ctrl$CF		# keep best global parameters
		minCases.best <<- ctrl$minCases
		error.min <<- error
	}
	
	return(error)
}

np = ceiling(0.5 * nrow(iris))

data.test <- iris[1:np,]
data.train <- iris[np+1:nrow(iris),]

vargs = c(85, 2)
accuracy <- 100 - error.fun(vargs)
accuracy

ga(type = 'real-valued', fitness = function(x) { -error.fun(x) }, 
	lower = c(2,2), upper = c(100,100), 
	popSize = 50, pcrossover = 0.8, pmutation = 0.1, 
	elitism = 10, monitor = gaMonitor, maxiter = 100)
	
accuracy <- 100 - error.min
accuracy
CF.best
minCases.best

