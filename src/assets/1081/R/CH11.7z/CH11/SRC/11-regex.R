rm(list=ls())
gc()

require(stringr)

# Extract names from raw data, :alpha: for alphabets, {2,} for 2 or more 
raw.data <- "555-1239Moe Szyslak(636) 555-0113Burns, C. Montgomery555-6542Rev. Timothy Lovejoy555 8904Ned Flanders636-555-3226Simpson, Homer5553642Dr. Julius Hibbert"
(name <- unlist(str_extract_all(raw.data, "[[:alpha:]., ]{2,}")))

# Extract telephone numbers, \d for digits
(phone <- unlist(str_extract_all(raw.data, "\\(?(\\d{3})?\\)?(-| )?\\d{3}(-| )?\\d{4}")))

data.frame(name = name, phone = phone)

example.obj <- "1. A small sentence. - 2. Another tiny sentence."
# extract punctuation characters
unlist(str_extract_all(example.obj, "[[:punct:]]"))

# match digits
unlist(str_extract_all(example.obj, "[[:digit:]]"))
unlist(str_extract_all(example.obj, "\\d"))

# backreferencing
# match the first alphabet character, which is 'A', and then match 'A' again
# reference 'A' using \\1
str_extract(example.obj, "([[:alpha:]]).+?\\1")

# any number with 1 or more digits
unlist(str_extract_all("16 candies for 8 children of age 10", "[0-9]+"))
# match the number at head of line
unlist(str_extract_all("16 candies for 8 children of age 10", "^[0-9]+"))
# matching anything other than numbers
unlist(str_extract_all("16 candies for 8 children of age 10", "[^0-9]+"))
# match the number at end of line
unlist(str_extract_all("16 candies for 8 children of age 10", "[0-9]+$"))


