rm(list=ls())
gc()

require(RCurl)

# list of curl options constances
names(getCurlOptionsConstants())

# fetch a web page
getURL("http://uscoj.im.usc.edu.tw/~ywdeng/files/1081/R/CH11/SRC/fortunes.html")

# download a PNG image file
pngfile <- getBinaryURL("http://uscoj.im.usc.edu.tw/~ywdeng/files/1081/R/CH11/SRC/11-1.png")
writeBin(pngfile, "world.png")

# Passing arguments to a Web page with GET
url <- "http://uscoj2.im.usc.edu.tw/~ywdeng/files/1081/R/CH11/SRC/hello.php"
namepar <- "Joseph"
sexpar <- "M"
require(stringr)
url_get <- str_c(url, "?", "name=", namepar, "&", "gender=", sexpar)
cat(getURL(url_get))

# using getForm
url <- "http://uscoj2.im.usc.edu.tw/~ywdeng/files/1081/R/CH11/SRC/hello.php"
cat(getForm(url, name="Mary", gender="F"))

# Passing arguments to a Web page with POST
url <- "http://uscoj2.im.usc.edu.tw/~ywdeng/files/1081/R/CH11/SRC/hello-post.php"
cat(postForm(url, name="John", gender="M"))

