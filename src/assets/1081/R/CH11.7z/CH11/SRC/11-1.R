rm(ls=list())
gc()

require(stringr)
require(XML)
require(maps)
require(curl)

# 瀕危世界遺產名錄
# Download the web page
conn <- curl("https://en.wikipedia.org/wiki/List_of_World_Heritage_in_Danger")
doc <- readLines(conn)

# parse the web page
heritage_parsed <- htmlParse(doc, encoding = "UTF-8")
tables <- readHTMLTable(heritage_parsed, stringsAsFactors = FALSE)

# extract Currently listed sites
danger_table <- tables[[2]]
head(danger_table)

danger_table <- danger_table[-1, c(1, 3, 4, 6, 7)]
colnames(danger_table) <- c("name", "location", "criteria", "yins", "yend")
danger_table$name[1:3]


danger_table$criteria <- ifelse(str_detect(danger_table$criteria, "Natural") == TRUE, "nat", "cult")
danger_table$criteria[1:3]

danger_table$yins <- as.numeric(danger_table$yins)
danger_table$yins[1:3]

# 瀕危年份， 2012- 只取數字 2012 
yend_clean <- unlist(str_extract_all(danger_table$yend, "^\\d{4}"))
danger_table$yend <- as.numeric(yend_clean)
danger_table$yend[1:3]

danger_table$location[c(1, 3, 5)]
reg_y <- "[/][ -]*[[:digit:]]*[.]*[[:digit:]]*[;]"
reg_x <- "[;][ -]*[[:digit:]]*[.]*[[:digit:]]*"
y_coords <- str_extract(danger_table$location, reg_y)
y_coords <- as.numeric(str_sub(y_coords, 3, -2))
danger_table$y_coords <- y_coords
x_coords <- str_extract(danger_table$location, reg_x)
x_coords <- as.numeric(str_sub(x_coords, 3, -1))
danger_table$x_coords <- x_coords
danger_table$location <- NULL

round(danger_table$y_coords, 2)[1:3]
round(danger_table$x_coords, 2)[1:3]

dim(danger_table)
head(danger_table)

pch <- ifelse(danger_table$criteria == "nat", 19, 2)
col <- ifelse(danger_table$criteria == "nat", "red", "blue")
map("world", col = "darkgrey", lwd = 0.5, mar = c(0.1, 0.1, 0.1, 0.1))
points(danger_table$x_coords, danger_table$y_coords, pch = pch, col = col)
box()

table(danger_table$criteria)

hist(danger_table$yend, freq = TRUE, xlab = "Year when site was put on the list of endangered sites", 
    main = "List of World Heritage in Danger")

duration <- danger_table$yend - danger_table$yins
hist(duration, freq = TRUE, xlab = "Years it took to become an endangered site",
    main = "List of World Heritage in Danger")
    