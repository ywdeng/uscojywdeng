<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>A PHP Hello World-GET</title>
</head>
<body>
<h1>PHP Hello 範例-GET</h1>
<hr />
<?php
if (! empty($_GET['name'])){
    $gender = (!empty($_GET['gender']) && ($_GET['gender'] == 'M')) ? '先生' : '小姐';
    echo '<h2>' . $_GET['name'] . '&nbsp;' . $gender . ' 您好!</h2>';
} else {
?>
<form action="hello.php" method="GET">
<p>
名稱: 
<input type="text" name="name"/>
</p>
<p>
性別: 
<input type="radio" name="gender" value="M" id="g-male" checked>
<label for="g-male">Male</label>
<input type="radio" name="gender" value="F" id="g-female">
<label for="g-female">Female</label>
</p>
<input type="submit">
</form>
<?php
}
?>
</body>
</html>