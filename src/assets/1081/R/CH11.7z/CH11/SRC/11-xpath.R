rm(list=ls())
gc()

require(XML)

setwd("D:/2019/USC/1081/R/CH11/SRC")

parsed_doc <- htmlParse(file = "fortunes.html")

print(parsed_doc)

# Absolute paths
xpathSApply(doc = parsed_doc, path = "/html/body/div/p/i")

# Relative paths
xpathSApply(parsed_doc, "//p/i")

# Wildcard operator
xpathSApply(parsed_doc, "/html/body/div/*/i")

# Selection expressions
# The .. operator selects the node one level up the hierarchy from the current node.
xpathSApply(parsed_doc, "//title/..")

# Multiple paths, | indicates OR
xpathSApply(parsed_doc, "//address | //title")

twoQueries <- c(address = "//address", title = "//title")
xpathSApply(parsed_doc, twoQueries)

# node1/relation::node2
# the <div> who is the ancestor of an <a>
xpathSApply(parsed_doc, "//a/ancestor::div")
# select thetextinitalics from this node set 
xpathSApply(parsed_doc, "//a/ancestor::div//i")

# select all the <p> nodes in the document and then all the <h1> siblings that precede these nodes
xpathSApply(parsed_doc, "//p/preceding-sibling::h1")

# every parent node for every <title> node in the document
xpathSApply(parsed_doc, "//title/parent::*")

