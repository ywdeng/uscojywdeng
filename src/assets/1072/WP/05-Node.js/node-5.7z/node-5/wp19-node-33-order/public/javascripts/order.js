function autoPostback() {
    var f = document.getElementById("mainForm");
    f.submit();
}