# Express MVC and Routing

範例：訂單管理

## Run locally

1. Install [Node.js and npm](https://nodejs.org/)
1. Run `git clone https://github.com/ywdeng/wp19-node-11-order.git`
1. Run `cd wp19-node-11-order`
1. Run `npm install`
1. Run `npm -g install nodemon`
1. Run `npm run test`
1. Visit [http://localhost:3000](http://localhost:3000)
