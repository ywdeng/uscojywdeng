# Sample Registration Form

An exercise for HTML form using various kinds of input tags.

## Run locally

1. Install [Node.js and npm](https://nodejs.org/)
1. Run `npm install`
1. Run `SET DEBUG=campregister:*`
1. Run `npm start`
1. Visit [http://localhost:3000](http://localhost:3000)


