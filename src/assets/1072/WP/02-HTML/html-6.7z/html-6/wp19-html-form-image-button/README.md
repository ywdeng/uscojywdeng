# Sample Registration Form

A sample [Express](http://expressjs.com/) application to demo HTML registration form with image button.

## Run locally

1. Install [Node.js and npm](https://nodejs.org/)
1. Run `git clone https://github.com/ywdeng/wp19-html-form-image-button.git`
1. Run `cd wp19-html-form-image-button`
1. Run `npm install`
1. Run `SET DEBUG=imagebutton:*`
1. Run `npm start`
1. Visit [http://localhost:3000](http://localhost:3000)


