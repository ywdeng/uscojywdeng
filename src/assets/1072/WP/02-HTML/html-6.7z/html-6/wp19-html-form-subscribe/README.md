# Subscribe to News Email
A simple HTML form example.

## Run locally

1. Install [Node.js and npm](https://nodejs.org/)
1. Clone the project `git clone https://github.com/ywdeng/wp19-html-form-subscribe.git`
1. Run `cd wp19-html-form-subscribe`
1. Run `npm install`
1. Run `set DEBUG=simpleform:*`
1. Run `npm start`
1. Visit [http://localhost:3000](http://localhost:3000)

